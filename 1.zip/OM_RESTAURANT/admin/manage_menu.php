 
 <html>
    <head>
    <title>Om Restaurant Menu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

    <style>
     
        .table img {
            height: 60px; 
            width: auto;
        }

        .button
        {
            color:white;
            margin: 1%;
            padding: 1%;
            font-weight: bold;
            font-size: 25px;
        }
    </style>
 </head>
     <body style="padding-top: 70px;">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="#">Om Restaurant</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMenu" aria-controls="navbarMenu" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarMenu">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                    <a class="nav-link" href="menu.php">Menu <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="add_menu.php">Add Menu</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                </ul>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>

    
    <?php    
    //Featch all Menu
    include('config/db.php');
    $items = $conn->query("SELECT * FROM menu_items");
     ?>

    
       
    <!-- ✅ Menu Items Table -->
    <h2 class="mt-5 mb-3">Menu Items (Table View)</h2>
    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Item Name</th>
                <th>Slogan</th>
                <th>Image</th>
                <th>Price</th>
                <th>Category</th>
                <th>Action</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $items->data_seek(0); // Reset pointer for second loop
            while($row = $items->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['item_name'] ?></td>
                <td><?= $row['slogan'] ?></td>
                <td>
                    <?php if ($row['img']): ?>
                        <img src="<?= $row['img'] ?>" alt="Image">
                    <?php else: ?>
                        <span>No image</span>
                    <?php endif; ?>
                </td>
                <td>₹<?= $row['price'] ?></td>
                <td><?= $row['category'] ?></td>
                <td><a href="update_menu.php?id=<?=$row['id']?>" class="btn btn-primary">Update</a></td>
                <td><a href="delete_menu.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger">Delete</a></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    </body>
</html>
