<?php
include('connection.php');

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['customer_name'];
    $contact = $_POST['contact'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $guests = $_POST['Guests'];

    $stmt = $conn->prepare("INSERT INTO reservation (customer_name, contact, date, time, Guests) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $name, $contact, $date, $time, $guests);

    if ($stmt->execute()) {
        $success = "Reservation booked successfully!";
    } else {
        $error = "Something went wrong. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book a Reservation</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .reservation-form {
            max-width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="#">Om Restaurant</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarReservation"
                        aria-controls="navbarReservation" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarReservation">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                    <a class="nav-link" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="admin/menu.php">Menu</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="admin/cart.php">Cart</a>
                    </li>
                    <li class="nav-item active">
                    <a class="nav-link" href="reservation.php">Reservation <span class="sr-only">(current)</span></a>
                    </li>
                </ul>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>

<div class="reservation-form">
    <h2 class="text-center mb-4">Book a Table</h2>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Your Name</label>
            <input type="text" name="customer_name" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Contact Number</label>
            <input type="tel" name="contact" class="form-control" required pattern="[0-9]{10}" maxlength="10" placeholder="e.g. 9876543210">
        </div>

        <div class="form-group">
            <label>Date</label>
            <input type="date" name="date" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Time</label>
            <input type="time" name="time" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Number of Guests</label>
            <input type="number" name="Guests" min="1" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary btn-block">Book Reservation</button>
    </form>
</div>

</body>
</html>
