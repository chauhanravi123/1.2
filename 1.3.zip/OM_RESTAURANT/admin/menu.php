<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "om_restaurant");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all items
$items = $conn->query("SELECT * FROM menu_items");
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $item = [
        'product_id' => $product_id,
        'name' => $name,
        'price' => $price,
        'quantity' => $quantity
    ];

    $_SESSION['cart'][] = $item;

    header("Location: menu.php?added=1");
    exit;
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Menu - Om Restaurant</title>

    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <style>
        /* Make all product images same size */
        .card-img-top {
            width: 100%;
            height: 200px;       /* fixed height */
            object-fit: cover;   /* crop and fill container */
        }
    </style>
</head>
            
<body class="container my-5">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
                <div class="container">
                    <a class="navbar-brand" href="#">Om Restaurant</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMenu"
                            aria-controls="navbarMenu" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarMenu">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                        <a class="nav-link" href="menu.php">Menu</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="cart.php">Cart</a>
                        </li>
                      
                    </ul>
                    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                    </div>
                </div>
            </nav>

    <h1 class="mb-4">Om Restaurant - Full Menu</h1>
    <button onclick="location.href='cart.php'"  style="width:100%; margin: 11px;"class="btn btn-primary">View Cart</button>
    <div class="row">
        <?php while($row = $items->fetch_assoc()): ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <?php if ($row['img']): ?>
                    <img src="<?= $row['img'] ?>" class="card-img-top" alt="Image">
                <?php else: ?>
                    <img src="https://via.placeholder.com/150" class="card-img-top" alt="No image">
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($row['item_name']) ?></h5>
                    <p class="card-text"><?= htmlspecialchars($row['descrption']) ?></p>
                    <p><strong>₹<?= htmlspecialchars($row['price']) ?></strong></p>
                    <span class="badge badge-secondary"><?= htmlspecialchars($row['category']) ?></span>

                    <!-- Add to Cart Form -->
                    <form method="POST" action="">
                        <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
                        <input type="hidden" name="name" value="<?= htmlspecialchars($row['item_name']) ?>">
                        <input type="hidden" name="price" value="<?= $row['price'] ?>">

                        <div class="form-group mt-2">
                            <label for="quantity_<?= $row['id'] ?>">Quantity:</label>
                            <input type="number" name="quantity" id="quantity_<?= $row['id'] ?>" class="form-control" value="1" min="1" required>
                        </div>

                        <button type="submit" name="add_to_cart" class="btn btn-primary btn-block">Add to Cart</button>
                    </form>
                </div>

            </div>
        </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
