<?php
session_start();
include('config/db.php');

// Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $item_name = $_POST['item_name'];
    $descrption = $_POST['descrption'];
    $price = $_POST['price'];
    $category = $_POST['category'];

    // Image Upload
    $img = "";
    if ($_FILES['img']['name']) {
        $img = "uploads/" . basename($_FILES['img']['name']);
        move_uploaded_file($_FILES['img']['tmp_name'], $img);
    }

    $sql = "INSERT INTO menu_items (item_name, descrption, img, price, category)
            VALUES ('$item_name', '$descrption', '$img', '$price', '$category')";

    if ($conn->query($sql) === TRUE) {
        $message = "<div class='alert alert-success'>New menu item added successfully!</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}

// Fetch all items
$items = $conn->query("SELECT * FROM menu_items");
?>

<!DOCTYPE html>
<html>
<body class="container my-5">
    <!DOCTYPE html>
<html>
<head>
    <title>Menu Management - Om Restaurant</title>
     <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body class="container pt-5 my-5">

            <!-- ✅ Navbar -->
        
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
                <a class="navbar-brand" href="#">Om Restaurant</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarAdmin" aria-controls="navbarAdmin" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarAdmin">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="menu.php">Menu <span class="sr-only"></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="orders.php">Orders</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php">Users</a>
                        </li>
                    </ul>
                    <span class="navbar-text">
                        <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                    </span>
                </div>
            </nav>

<!-- Apply padding to push down content below fixed navbar -->


        
   
    <?= isset($message) ? $message : '' ?>

<!-- Your form and page content here -->

    <h1 class="mb-4 text-center">Om Restaurant - Menu Management</h1>
        

    <?= isset($message) ? $message : '' ?>

    <!-- ✅ Add Menu Form -->
    <form method="POST" enctype="multipart/form-data" class="mb-5 border p-4 rounded bg-light">
        <h4 class="mb-3">Add New Menu Item</h4>
        <div class="form-group">
            <label>Item Name</label>
            <input type="text" name="item_name" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Descrption</label>
            <input type="text" name="descrption" class="form-control">
        </div>
        <div class="form-group">
            <label>Image</label>
            <input type="file" name="img" class="form-control-file">
        </div>
        <div class="form-group">
            <label>Price (₹)</label>
            <input type="number" step="0.01" name="price" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Category</label>
            <input type="text" name="category" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Add Menu Item</button>
    </form>

  
</body>
</html>
