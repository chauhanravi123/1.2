<?php
session_start();
include('config/db.php');

// Uncomment the next line to protect the page
// if (!isset($_SESSION['admin'])) header("Location: ../login.php");

$orders = $conn->query("SELECT * FROM orders ORDER BY order_id DESC");

// Handle status updates or deletions if requested
if (isset($_GET['action']) && isset($_GET['id'])) {
    $orderId = intval($_GET['id']);
    $action = $_GET['action'];

    if (in_array($action, ['delivered', 'pending', 'cancelled'])) {
        $conn->query("UPDATE orders SET status='$action' WHERE order_id=$orderId");
    } elseif ($action == 'delete') {
        $conn->query("DELETE FROM orders WHERE order_id=$orderId");
    }

    // Redirect to the same page to avoid resubmitting the action
    header("Location: orders.php");
    exit;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Management</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">

    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', sans-serif;
        }
        .container {
            margin-top: 40px;
        }
        .orders-table {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
        }
        .orders-table h2 {
            margin-bottom: 25px;
            text-align: center;
            color: #333;
        }
        .table th {
            background-color: #343a40;
            color: white;
            text-align: center;
        }
        .table td {
            vertical-align: middle;
            text-align: center;
        }
        .order-date {
            font-weight: bold;
            color: #007bff;
        }
        .navbar {
            margin-bottom: 30px;
        }
    </style>
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Admin Panel</a>
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active"><a class="nav-link" href="orders.php">Orders</a></li>
            <li class="nav-item"><a class="nav-link" href="menu.php">Products</a></li>
           
        </ul>
        <span class="navbar-text">
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </span>
    </div>
</nav>

<!-- ✅ Order Table -->
<div class="container">
    <div class="orders-table">
        <h2>Order Management</h2>
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($order = $orders->fetch_assoc()): ?>
                <tr>
                    <td><?= $order['order_id'] ?></td>
                    <td><?= $order['customer_name'] ?></td>
                    <td><?= $order['items'] ?></td>
                    <td>₹<?= number_format($order['total'], 2) ?></td>
                    <td><?= ucfirst($order['status']) ?></td>
                    <td class="order-date"><?= date("d M Y", strtotime($order['date'])) ?></td>
                    <td>
                        <a href="?action=delivered&id=<?= $order['order_id'] ?>" class="btn btn-success btn-sm mb-1">Delivered</a>
                        <a href="?action=pending&id=<?= $order['order_id'] ?>" class="btn btn-warning btn-sm mb-1">Pending</a>
                        <a href="?action=cancelled&id=<?= $order['order_id'] ?>" class="btn btn-danger btn-sm mb-1">Cancelled</a>
                        <a href="?action=delete&id=<?= $order['order_id'] ?>" class="btn btn-outline-danger btn-sm mb-1" onclick="return confirm('Are you sure you want to delete this order?')">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
