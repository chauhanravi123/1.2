<?php
// login.php
include 'connection.php';
session_start();

// Initialize message variables
$message = '';
$color = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        
        // Verify password (plain text comparison - NOT RECOMMENDED for production)
        if ($data['password'] == $password) {
            // Set session variables
            $_SESSION['user_id'] = $data['id'];
            $_SESSION['email'] = $data['email'];
            $_SESSION['loggedin'] = true;
            
            // Redirect after successful login
            header("Location: index.php");
            exit();
        } else {
            $message = "Wrong password!";
            $color = "orange";
        }
    } else {
        $message = "Email not registered. Please register first!";
        $color = "red";
    }
    
    // Don't redirect here if login failed - we want to show the error message
}
?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login GUI</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #74ebd5, #acb6e5);
            display: flex;
            height: 100vh;
            align-items: center;
            justify-content: center;
            margin: 0;
        }

        .login-box {
            background: #fff;
            padding: 40px 30px;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-box h2 {
            margin-bottom: 25px;
            color: #333;
        }

        label {
            display: block;
            text-align: left;
            margin-bottom: 6px;
            font-weight: 600;
            color: #444;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #6c63ff;
            outline: none;
        }

        button[type="submit"] {
            width: 100%;
            padding: 12px;
            background: #6c63ff;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button[type="submit"]:hover {
            background: #574fd6;
        }

        .message {
            margin-top: 20px;
            font-weight: bold;
            color: #d8000c;
        }

        /* Responsive design */
        @media (max-width: 480px) {
            .login-box {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>

<div class="login-box">
    <h2>Login</h2>
    <form method="POST" action="login.php">
        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="Enter your email" required>
         
        <label for="password">Password</label>
        <input type="password" name="password" id="password" placeholder="Enter your password" required>
        
        <button type="submit">Login</button>
        <button type="submit"><a href="admin/index.php">Admin Login</button>
        New User:
        <a href="register.php">Register</a>
    </form>

    <?php if (isset($message)): ?>
        <div class="message" style="color: <?= $color ?>;">
            <?= $message ?>
        </div>
    <?php endif; ?>
</div>

</body>
 
</html>
