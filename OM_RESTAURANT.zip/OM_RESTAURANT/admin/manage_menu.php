 
 <html>
    <head>
    <title>Om Restaurant Menu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
     
        .table img {
            height: 60px; 
            width: auto;
        }

        .button
        {
            color:white;
            margin: 1%;
            padding: 1%;
            font-weight: bold;
            font-size: 25px;
        }
    </style>
</head>
    <body>
    
    
    <?php    
    //Featch all Menu
    include('config/db.php');
    $items = $conn->query("SELECT * FROM menu_items");
     ?>

    <!-- ADD NEW MENU ITEMS -->
            <div class="button">
                <a href="add_menu.php" class="btn btn-primary">Add Menu</a>
            </div>
       
    <!-- ✅ Menu Items Table -->
    <h2 class="mt-5 mb-3">Menu Items (Table View)</h2>
    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Item Name</th>
                <th>Slogan</th>
                <th>Image</th>
                <th>Price</th>
                <th>Category</th>
                <th>Action</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $items->data_seek(0); // Reset pointer for second loop
            while($row = $items->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['item_name'] ?></td>
                <td><?= $row['slogan'] ?></td>
                <td>
                    <?php if ($row['img']): ?>
                        <img src="<?= $row['img'] ?>" alt="Image">
                    <?php else: ?>
                        <span>No image</span>
                    <?php endif; ?>
                </td>
                <td>₹<?= $row['price'] ?></td>
                <td><?= $row['category'] ?></td>
                <td><a href="update_menu.php?id=<?=$row['id']?>" class="btn btn-primary">Update</a></td>
                <td><a href="delete_menu.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger">Delete</a></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    </body>
</html>
