<?php
// DB connection
$servername = "localhost";
$username = "root";
$password = "";  
$dbname = "om_restaurant";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $item_name = $category = $price = $img = "";
$updateSuccess = false;

// Check if form is submitted for update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $item_name = $_POST['item_name'];
    $slogan = $_POST['slogan'];
    $category = $_POST['category'];
    $price = $_POST['price'];

    // File upload handling
    if (isset($_FILES['img']) && $_FILES['img']['error'] === UPLOAD_ERR_OK) {
        $img_tmp = $_FILES['img']['tmp_name'];
        $img_name = basename($_FILES['img']['name']);
        $upload_dir = 'uploads/';
        $img_path = $upload_dir . $img_name;

        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        move_uploaded_file($img_tmp, $img_path);
    } else {
        // No new image, fetch current image
        $stmt_img = $conn->prepare("SELECT img FROM menu_items WHERE id = ?");
        $stmt_img->bind_param("i", $id);
        $stmt_img->execute();
        $result_img = $stmt_img->get_result();
        $row_img = $result_img->fetch_assoc();
        $img_path = $row_img['img'];
    }

    // Update statement
    $stmt = $conn->prepare("UPDATE menu_items SET item_name=?, slogan=?, category=?, price=?, img=? WHERE id=?");
    $stmt->bind_param("sssdsi", $item_name, $slogan, $category, $price, $img_path, $id);

    if ($stmt->execute()) {
        $updateSuccess = true;
    }
}

?>








<!-- HTML Form -->
<!DOCTYPE html>
<html>
<head>
    <title>Update Menu Item</title>
    <style>

        /* Container */
.update-form {
  max-width: 400px;
  margin: 30px auto;
  padding: 20px 25px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background: #fafafa;
  font-family: Arial, sans-serif;
}

/* Form labels */
.update-form label {
  display: block;
  margin-bottom: 6px;
  font-weight: 600;
  color: #333;
}

/* Inputs */
.update-form input[type="text"],
.update-form input[type="number"],
.update-form input[type="file"] {
  width: 100%;
  padding: 8px 12px;
  margin-bottom: 15px;
  border: 1.5px solid #ccc;
  border-radius: 4px;
  font-size: 1rem;
  box-sizing: border-box;
  transition: border-color 0.3s ease;
}

/* Input focus */
.update-form input[type="text"]:focus,
.update-form input[type="number"]:focus,
.update-form input[type="file"]:focus {
  border-color: #007bff;
  outline: none;
}

/* Submit button */
.update-form button {
  width: 100%;
  background-color: #007bff;
  color: white;
  border: none;
  padding: 12px 0;
  font-size: 1.1rem;
  font-weight: bold;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.update-form button:hover {
  background-color: #0056b3;
}

    </style>
</head>
<body>
    <h2>Update Menu Item</h2>

    <?php if ($updateSuccess): ?>
        <p style="color: green;">Item updated successfully!</p>
    <?php endif; ?>

    <form action="update_menu.php" method="post" enctype="multipart/form-data" class="update-form">
        <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">

        <label>Item Name:</label><br>
        <input type="text" id="name" name="item_name" value="<?= htmlspecialchars($item_name) ?>" required><br><br>

        <label>Slogan</label>
        <input type="text" id="name" name="slogan" value="<?=htmlspecialchars($slogan)?>"required><br><br>

        <label>Category:</label><br>
        <input type="text" id="name" name="category" value="<?= htmlspecialchars($category) ?>" required><br><br>

        <label>Price:</label><br>
        <input type="number" id="price" step="0.01" name="price" value="<?= htmlspecialchars($price) ?>" required><br><br>

        <label>Image URL:</label><br>
       <input type="file" name="img" id="img" accept="image/*" value="<?= htmlspecialchars($img ?? '') ?>"><br><br>

        <button type="submit">Update</button>
    </form>
</body>
</html>

  
