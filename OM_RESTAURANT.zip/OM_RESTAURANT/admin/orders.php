<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

include('config/db.php');

$orders = $conn->query("SELECT * FROM orders ORDER BY order_id DESC");

if (isset($_GET['action']) && isset($_GET['id'])) {
    $orderId = intval($_GET['id']);
    $action = $_GET['action'];

    if (in_array($action, ['delivered', 'pending', 'cancelled'])) {
        $conn->query("UPDATE orders SET status='$action' WHERE order_id=$orderId");
    } elseif ($action == 'delete') {
        $conn->query("DELETE FROM orders WHERE order_id=$orderId");
    }

    header("Location: orders.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Management</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', sans-serif;
        }
        .container {
            margin-top: 40px;
        }
        .orders-table {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
        }
        .orders-table h2 {
            margin-bottom: 25px;
            text-align: center;
            color: #333;
        }
        .table th {
            background-color: #343a40;
            color: white;
            text-align: center;
        }
        .table td {
            vertical-align: middle;
            text-align: center;
        }
        .order-date {
            font-weight: bold;
            color: #007bff;
        }
        .navbar-nav {
            margin-left: 75%;
        }
        .btn:hover {
            transform: scale(1.05);
            transition: transform 0.2s ease-in-out;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Om Restaurant</a>
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav">
            <li class="nav-item active"><a class="nav-link" href="orders.php">Orders</a></li>
            <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        </ul>
        <span class="navbar-text">
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </span>
    </div>
</nav>

<div class="container">
    <div class="orders-table">
        <h2>Order Management</h2>
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                    <th>Bill</th>
                </tr>
            </thead>
            <tbody>
                <?php while($order = $orders->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($order['order_id']) ?></td>
                    <td><?= htmlspecialchars($order['customer_name']) ?></td>
                    <td><?= htmlspecialchars($order['phone']) ?></td>
                    <td><?= htmlspecialchars($order['address']) ?></td>
                    <td>
                        <?php 
                        $items = json_decode($order['items'], true); 
                        if (is_array($items)) {
                            foreach ($items as $item) {
                                echo htmlspecialchars($item['name']) . " × " . intval($item['quantity']) . " x ₹" . number_format($item['price'], 2) . "<br>";
                            }
                        } else {
                            echo "Invalid item data";
                        }
                        ?>
                    </td>
                    <td>₹<?= number_format($order['total'], 2) ?></td>
                    <td><?= ucfirst(htmlspecialchars($order['status'])) ?></td>
                    <td class="order-date"><?= date("d M Y", strtotime($order['date'])) ?></td>
                    <td>
                        <div class="btn-group" role="group" aria-label="Order status actions">
                            <a href="?action=delivered&id=<?= $order['order_id'] ?>" class="btn btn-success btn-sm" title="Mark as Delivered">
                                <i class="bi bi-check-circle"></i>
                            </a>
                            <a href="?action=pending&id=<?= $order['order_id'] ?>" class="btn btn-warning btn-sm" title="Mark as Pending">
                                <i class="bi bi-clock-history"></i>
                            </a>
                            <a href="?action=cancelled&id=<?= $order['order_id'] ?>" class="btn btn-danger btn-sm" title="Mark as Cancelled">
                                <i class="bi bi-x-circle"></i>
                            </a>
                            <a href="?action=delete&id=<?= $order['order_id'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Are you sure you want to delete this order?')" title="Delete Order">
                                <i class="bi bi-trash"></i>
                            </a>
                        </div>
                    </td>
                    <td>
                        <a href="generate_bill.php?id=<?= $order['order_id'] ?>" class="btn btn-primary btn-sm mb-1">Generate Bill</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS and dependencies for tooltips -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    $(function () {
        $('[title]').tooltip();
    });
</script>

</body>
</html>
