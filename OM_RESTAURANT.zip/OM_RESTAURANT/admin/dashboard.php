<?php
session_start();

include('config/db.php');
include('includes/header.php');

// Example counts (use optional checks to avoid errors if tables are missing)
$menu_count = $conn->query("SELECT COUNT(*) FROM menu_items")->fetch_row()[0];

// Optional: Uncomment after tables are created
//$order_count = $conn->query("SELECT COUNT(*) FROM orders")->fetch_row()[0];
//$reservation_count = $conn->query("SELECT COUNT(*) FROM reservations")->fetch_row()[0];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>

  <!-- ✅ Bootstrap CSS (optional but recommended) -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      background-color: #f7f9fc;
      font-family: Arial, sans-serif;
    }
    .dashboard-container {
      max-width: 800px;
      margin: 50px auto;
      padding: 30px;
      background: white;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      border-radius: 8px;
    }
    h1 {
      text-align: center;
      margin-bottom: 30px;
      color: #343a40;
    }
    .stat-box {
      padding: 20px;
      margin-bottom: 15px;
      border: 1px solid #e0e0e0;
      border-radius: 5px;
      background-color: #f1f1f1;
    }
    .dashboard-links {
      text-align: center;
      margin-top: 30px;
    }
    .dashboard-links a {
      margin: 0 10px;
      text-decoration: none;
      font-weight: bold;
      color: #007bff;
    }
    .dashboard-links a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="dashboard-container">
    <h1>Admin Dashboard</h1>

    <div class="stat-box">
        <p><strong>Total Menu Items:</strong> <?= $menu_count ?></p>
    </div>

    <!-- Uncomment these when you have the tables -->
    <!--
    <div class="stat-box">
        <p><strong>Total Orders:</strong> <?= $order_count ?></p>
    </div>
    <div class="stat-box">
        <p><strong>Total Reservations:</strong> <?= $reservation_count ?></p>
    </div>
    -->

    <div class="dashboard-links">
        <a href="add_menu.php">Manage Menu</a>
        <a href="orders.php">View Orders</a>
        <a href="view_reserva.php">Manage Reservations</a>
        <a href="users.php">Manage Users</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

</body>
</html>

<?php include('includes/footer.php'); ?>
