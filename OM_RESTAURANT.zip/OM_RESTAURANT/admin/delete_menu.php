<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
include ('config/db.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    echo "Deleting ID: $id<br>";

    $stmt = $conn->prepare("DELETE FROM menu_items WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert(Record deleted successfully.);</script><br>";
        header("Location: menu.php?msg=deleted");
        exit();
    } else {
        echo "Error deleting item: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "No ID provided.";
}

$conn->close();
?>
