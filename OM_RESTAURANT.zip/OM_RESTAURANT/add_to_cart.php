<?php
// Fetch products from DB

$server="localhost";
$user ="root";
$password ="";
$dbname ="om_restaurant";

 $conn= mysqli_connect($server,$user,$password,$dbname);

 if(!$conn)
      die("Connection failed: " . mysqli_connect_error());
$result = mysqli_query($conn, "SELECT * FROM menu_items");

session_start();
$cart = $_SESSION['cart'] ?? [];
$total = 0;





?>

<!DOCTYPE html>
<html>
<head>
    <title>Menu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Menu</h2>

    <?php if (isset($_GET['added'])): ?>
        <div class="alert alert-success">Product added to cart!</div>
    <?php endif; ?>

    <div class="row">
        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                       <?php if ($row['img']): ?>
                    <img src="<?= $row['img'] ?>" class="card-img-top" alt="Image">
                <?php else: ?>
                    <img src="https://via.placeholder.com/150" class="card-img-top" alt="No image">
                <?php endif; ?>
                    <h5><?= htmlspecialchars($row['item_name']) ?></h5>
                    <p><?= htmlspecialchars($row['slogan']) ?></p>
                    <p>Price: ₹<?= $row['price'] ?></p>

                         <form method="post" action="menu.php">
                                <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
                                <input type="hidden" name="name" value="<?= $row['item_name'] ?>">
                                <input type="hidden" name="price" value="<?= $row['price'] ?>">
                                <div class="form-group">
                                    <label>Quantity</label>
                                   <input type="number" name="quantity" value="1" min="1" class="form-control" required>
                                </div>
                                <button type="submit" name="add_to_cart" class="btn btn-success btn-block">Add to Cart</button>
                         </form>

                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>
</body>
</html>
