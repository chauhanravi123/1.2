<?php
// generate_bill.php
include('config/db.php');

// Get order ID
if (!isset($_GET['id'])) {
    die("Order ID not provided.");
}
$order_id = intval($_GET['id']);

// Fetch order
$result = $conn->query("SELECT * FROM orders WHERE order_id = $order_id");
if ($result->num_rows == 0) {
    die("Order not found.");
}

$order = $result->fetch_assoc();
$items = json_decode($order['items'], true); // assuming items are stored as JSON
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bill - Order #<?= $order_id ?></title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <style>
        .bill-container {
            width: 700px;
            margin: 50px auto;
            padding: 30px;
            background: white;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        .restaurant-name {
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .bill-header, .bill-footer {
            margin-bottom: 20px;
        }
        .total {
            font-weight: bold;
            font-size: 18px;
            text-align: right;
        }
        .btn-print {
            margin-top: 20px;
            text-align: center;
        }
        @media print {
            .btn-print {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="bill-container">
    <div class="restaurant-name">Om Restaurant</div>

    <div class="bill-header">
        <p><strong>Order ID:</strong> <?= $order['order_id'] ?></p>
        <p><strong>Customer:</strong> <?= $order['customer_name'] ?></p>
        <p><strong>Date:</strong> <?= date("d M Y, h:i A", strtotime($order['date'])) ?></p>
        <p><strong>Status:</strong> <?= ucfirst($order['status']) ?></p>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Item</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $grandTotal = 0;
            foreach ($items as $item) {
                $lineTotal = $item['qty'] * $item['price'];
                $grandTotal += $lineTotal;
                echo "<tr>
                        <td>{$item['name']}</td>
                        <td>{$item['qty']}</td>
                        <td>₹{$item['price']}</td>
                        <td>₹{$lineTotal}</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="total">
        Grand Total: ₹<?= number_format($grandTotal, 2) ?>
    </div>

    <div class="btn-print text-center">
        <button class="btn btn-success" onclick="window.print()">Print Bill</button>
        <a href="orders.php" class="btn btn-secondary">Back to Orders</a>
    </div>
</div>

</body>
</html>
