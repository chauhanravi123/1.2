-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 29, 2025 at 06:27 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `om_restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `name`, `email`, `password`, `date`) VALUES
(1, 'Maa', 'maa@gmail.com', '971289', '2025-07-03 09:22:42.000000');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int NOT NULL,
  `item_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `slogan` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `img` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `price` float NOT NULL,
  `category` varchar(250) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `item_name`, `slogan`, `img`, `price`, `category`) VALUES
(3, 'Masala Dhosa', 'Masala Dhosa like Potato masala is in paper', 'uploads/masala-dhosa', 150, 'South-Indian'),
(5, 'Dhokla', 'Khaman Dhokala', 'uploads/khaman', 35, 'Gujrati'),
(6, 'Kathiyawadi Thali', 'Rotali ,shak, dal,bhat,sweet, dahi, salad, papad,thepla achar etc.', 'uploads/image.png', 191, 'Gujrati'),
(7, 'Dal Bati', 'dal, bati, churma, chas, papad', 'uploads/dalbati.jpg', 151, 'Rajshtahni');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `customer_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `items` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `total` float NOT NULL,
  `status` enum('deliverd','pending') COLLATE utf8mb4_general_ci NOT NULL,
  `date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_name`, `items`, `total`, `status`, `date`) VALUES
(1, 'jay', 'Masala Dosha', 0, 'deliverd', '2025-07-03 09:22:42.000000'),
(2, 'Yogesh', 'Masala dhosa, khaman', 201, 'deliverd', '2025-07-03 09:22:42.000000');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `rs_id` int NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `date` date NOT NULL,
  `time` time(6) NOT NULL,
  `Guests` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`rs_id`, `customer_name`, `contact`, `date`, `time`, `Guests`) VALUES
(1, 'Jaydip', '0', '2025-08-03', '08:15:30.000000', 21),
(2, 'Yogesh Parmar', '9926741301', '2025-08-03', '10:15:00.000000', 29),
(3, 'JAY ', '9926741301', '2025-08-03', '09:30:00.000000', 25);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cpassword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `password`, `cpassword`, `address`) VALUES
(55, 'maa', '9712895171', 'maa@gmail.com', '971289', '971289', 'laxminagar,bhagat ni vadi,turkha road,botad'),
(56, 'ravi', '0123456788', 'jay@gmail.com', '123321', '123321', 'rajkot'),
(57, 'yogesh', '9829969705', 'yogeh@gmail.com', '123456', '123456', 'rajkot'),
(60, 'mahesh', '9829969701', 'mahesh@gmail.com', 'mahesh', 'mahesh', 'Dhakaniya Road,Botad ,Gujrat'),
(61, 'Anand Chauhan', '8758328690', 'anandchauhan43339@gmail.com', '123456', '123456', 'botad'),
(62, 'sachin', '7777884318', 'sachin@gmail.com', 'sachin', 'sachin', 'jamnagar'),
(63, 'mehul', '9904190160', 'mehul@gmail.com', 'mehul1', 'mehul1', 'vakil ni vadi,botad');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `rs_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
