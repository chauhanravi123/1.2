-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 26, 2025 at 06:32 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `om_restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `name`, `email`, `password`, `date`) VALUES
(1, 'Maa', 'maa@gmail.com', '971289', '2025-07-03 09:22:42.000000');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `number`, `email`, `message`) VALUES
(8, 'ravi', '01234567889', 'jay@gmail.com', 'Hello '),
(9, 'ravi', '01234567889', 'jay@gmail.com', 'Hello '),
(10, 'PARMAR JAYDIP', '9016098425', 'jaydip@gmail.com', 'how many restaurant available in your website.\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int NOT NULL,
  `item_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `descrption` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `img` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `price` float NOT NULL,
  `category` varchar(250) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `item_name`, `descrption`, `img`, `price`, `category`) VALUES
(3, 'Masala Dhosa', 'Masala Dhosa like Potato masala is in paper', 'uploads/south-indian.jpg', 150, 'South-Indian'),
(6, 'Kathiyawadi Thali', 'Rotali ,shak, dal,bhat,sweet, papad,thepla etc.', 'uploads/gujrtitahali.jpg', 171, 'Gujrati'),
(7, 'Dal Bati', 'dal, bati, churma, chas, papad', 'uploads/dalbati.jpg', 151, 'Rajshtahni'),
(8, 'Burger', 'contains cheese allootiki onion .', 'uploads/burger.jpg', 49, 'Vegetarian'),
(9, 'Punjabi Thali', 'Butter Nan, Paneer Subji, butter milk etc.', 'uploads/punjabi.jpg', 199, 'Punjabi'),
(10, 'Undhiyu Puri', 'mikash sabjai, puri .', 'uploads/Chapdi-undhiyu-WS-1.jpg', 99, 'Gujrati');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `customer_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `items` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `total` float NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date` datetime(6) NOT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_name`, `items`, `total`, `status`, `date`, `user_id`) VALUES
(23, 'JAY ', '[{\"product_id\":\"3\",\"name\":\"Masala Dhosa\",\"price\":\"150\",\"quantity\":\"1\"}]', 150, 'delivered', '2025-08-25 03:39:23.000000', 68),
(24, 'Yogesh Parmar', '[{\"product_id\":\"3\",\"name\":\"Masala Dhosa\",\"price\":\"150\",\"quantity\":\"1\"}]', 150, 'delivered', '2025-08-25 13:09:56.000000', 60),
(25, 'Yogesh Parmar', '[{\"product_id\":\"3\",\"name\":\"Masala Dhosa\",\"price\":\"150\",\"quantity\":\"1\"}]', 150, 'delivered', '2025-08-25 13:10:32.000000', 60),
(26, 'jaydip', '[{\"product_id\":\"8\",\"name\":\"Burger\",\"price\":\"59\",\"quantity\":\"1\"}]', 59, 'delivered', '2025-08-25 13:14:10.000000', 68),
(27, 'parmar yogesh', '[{\"product_id\":\"10\",\"name\":\"Undhiyu Puri\",\"price\":\"99\",\"quantity\":\"1\"}]', 99, 'delivered', '2025-08-26 05:48:40.000000', 67);

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `rs_id` int NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `date` date NOT NULL,
  `time` time(6) NOT NULL,
  `Guests` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`rs_id`, `customer_name`, `contact`, `date`, `time`, `Guests`) VALUES
(1, 'Jaydip', '0', '2025-08-03', '08:15:30.000000', 21),
(2, 'Yogesh Parmar', '9926741301', '2025-08-03', '10:15:00.000000', 29),
(3, 'JAY ', '9926741301', '2025-08-03', '09:30:00.000000', 25),
(4, 'JAY ', '9926741301', '2025-08-03', '10:30:00.000000', 25);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `rs_id` int NOT NULL,
  `c_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `o_hr` time(6) NOT NULL,
  `c_hr` time(6) NOT NULL,
  `o_days` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cpassword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `password`, `cpassword`, `address`) VALUES
(60, 'mahesh', '9829969701', 'mahesh@gmail.com', 'mahesh', 'mahesh', 'Dhakaniya Road,Botad ,Gujrat'),
(67, 'Yogesh Parmar', '9924841309', 'yogesh@gmail.com', 'yogesh', 'yogesh', 'laxminagar,bhagat ni vadi,turkha road,botad'),
(68, 'PARMAR JAYDIP', '9824231560', 'jaydip@gmail.com', 'Jaydip', 'Jaydip', 'Botad ,Gujrat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `rs_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `rs_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
