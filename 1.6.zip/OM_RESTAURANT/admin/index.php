<?php
session_start();
include('config/db.php');

// Turn on error reporting during development (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['name'];
    $password = $_POST['password'];

    // Prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM admin WHERE name = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password); // assuming plain text (not secure — see notes)
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $_SESSION["adm_id"] = $row['adm_id'];
        $_SESSION["admin_logged_in"] = true;
        $_SESSION["username"] = $row['name'];

        header("Location: dashboard.php");
        exit; // 🔥 SUPER IMPORTANT!
    } else {
        // Safe way to show error
        $error = "Invalid Username or Password!";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>

    <!-- OPTIONAL: Bootstrap CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f0f0f0;
            font-family: Arial, sans-serif;
        }
        .login-container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            margin: 100px auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }
        .login-container h2 {
            margin-bottom: 20px;
            text-align: center;
            color: #333;
        }
        .form-control {
            margin-bottom: 15px;
        }
        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Admin Login</h2>
    <form method="post">
        <input type="text" name="name" class="form-control" required placeholder="Username">
        <input type="password" name="password" class="form-control" required placeholder="Password">
        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
    <?php if (isset($error)) echo "<p class='error mt-3'>$error</p>"; ?>
</div>

</body>
</html>
