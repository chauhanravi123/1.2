<?php
session_start();
$conn = new mysqli("localhost", "root", "", "om_restaurant");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Remove item from cart
if (isset($_GET['remove'])) {
    $remove_index = (int)$_GET['remove'];
    if (isset($_SESSION['cart'][$remove_index])) {
        unset($_SESSION['cart'][$remove_index]);
        $_SESSION['cart'] = array_values($_SESSION['cart']); // Reindex
    }
    header("Location: cart.php");
    exit;
}

// Clear cart
if (isset($_GET['clear'])) {
    $_SESSION['cart'] = [];
    header("Location: cart.php");
    exit;
}

// Checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php?redirect=cart.php");
        exit;
    }

    $customer_name = $conn->real_escape_string($_POST['customer_name']);
    $phone = trim($_POST['phone']);
    $address = $conn->real_escape_string($_POST['address']);
    $cartItems = $_SESSION['cart'];

    // Server-side phone validation (Indian 10-digit number starting with 6-9)
    if (!preg_match('/^[6-9]\d{9}$/', $phone)) {
         die("Invalid phone number. Please enter a 10-digit Indian mobile number starting with 6-9.");
    }

    if (empty($cartItems)) {
        $error = "Cart is empty!";
    } else {
        $user_id = $_SESSION['user_id'];
        $order_id = 'ORD' . date('YmdHis') . rand(100, 999);
        $items_json = json_encode($cartItems);
        $total = 0;

        foreach ($cartItems as $item) {
            $total += $item['price'] * $item['quantity'];
        }

        $status = 'Pending';
        $date = date('Y-m-d H:i:s');

        // Use prepared statements for security
        $stmt = $conn->prepare("INSERT INTO orders (user_id, customer_name, phone, address, items, total, status, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssdss", $user_id, $customer_name, $phone, $address, $items_json, $total, $status, $date);

        if ($stmt->execute()) {
            $_SESSION['cart'] = []; // Clear cart
            $success = "Order placed successfully! Your Order ID is <strong>$order_id</strong>";
        } else {
            $error = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cart - Om Restaurant</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <style>
        body { padding-top: 70px; }
        #navbarNavCart {
            margin-left: 65%;
        }
        .is-invalid {
            border-color: #dc3545;
        }
        .error-message {
            display: none;
        }
    </style>
</head>
<body class="container pt-5 my-5">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="#">Om Restaurant</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavCart">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavCart">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
            <li class="nav-item active"><a class="nav-link" href="cart.php">Cart</a></li>
            <li class="nav-item active"><a class="nav-link" href="../Myorders.php">Orders</a></li>
        </ul>
        <span class="navbar-text">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
            <?php else: ?>
                <a href="../login.php" class="btn btn-outline-light btn-sm">Login</a>
            <?php endif; ?>
        </span>
    </div>
</nav>

<h1 class="mb-4">Your Cart</h1>

<?php if (!empty($success)): ?>
    <div class="alert alert-success"><?= $success ?></div>
<?php elseif (!empty($error)): ?>
    <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<?php if (empty($_SESSION['cart'])): ?>
    <p>Your cart is empty. </p><!-- <a href="menu.php">Go back to menu</a> -->
<?php else: ?>
    <a href="cart.php?clear=1" class="btn btn-warning mb-3" onclick="return confirm('Clear entire cart?')">Clear Cart</a>
    <a href="menu.php" class="btn btn-primary mb-3 ml-2">Add More Items</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Item</th>
                <th>Price (₹)</th>
                <th>Quantity</th>
                <th>Subtotal (₹)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $total = 0;
        foreach ($_SESSION['cart'] as $index => $item):
            $subtotal = $item['price'] * $item['quantity'];
            $total += $subtotal;
        ?>
            <tr>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td><?= number_format($item['price'], 2) ?></td>
                <td><?= $item['quantity'] ?></td>
                <td><?= number_format($subtotal, 2) ?></td>
                <td>
                    <a href="cart.php?remove=<?= $index ?>" class="btn btn-danger btn-sm" onclick="return confirm('Remove this item?')">Remove</a>
                </td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <th colspan="3" class="text-right">Total</th>
            <th>₹<?= number_format($total, 2) ?></th>
            <th></th>
        </tr>
        </tbody>
    </table>

    <h3 class="mt-4">Checkout</h3>
    <?php if (!isset($_SESSION['user_id'])): ?>
        <div class="alert alert-warning">
            Please <a href="../login.php">log in</a> to proceed with checkout.
        </div>
    <?php else: ?>
        <form method="POST" onsubmit="return register()">
            <div class="form-group">
                <label>Customer Name</label>
                <input type="text" name="customer_name" id="customer_name" class="form-control" required>
                <small id="name-error" class="text-danger error-message">Name is required.</small>

                <label>Phone</label>
                <input type="text" id="phone" name="phone" class="form-control" required>
                <small id="phone-error" class="text-danger error-message">Enter valid 10-digit Indian phone number.</small>

                <label>Address</label>
                <input type="text" id="address" name="address" class="form-control" required>
                <small id="address-error" class="text-danger error-message">Address is required.</small>
            </div>
            <button type="submit" name="checkout" class="btn btn-success">Place Order</button>
        </form>
    <?php endif; ?>
<?php endif; ?>

<a href="menu.php" class="btn btn-secondary mt-4">Back to Menu</a>

<script>
function register() {
    // Reset previous errors
    document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');
    document.querySelectorAll('input').forEach(input => input.classList.remove('is-invalid'));

    // Get form values
    var name = document.getElementById("customer_name").value.trim();
    var phone = document.getElementById("phone").value.trim();
    var address = document.getElementById("address").value.trim();

    var isValid = true;

    // Validate name
    if (name === "") {
        document.getElementById("name-error").style.display = "block";
        document.getElementById("customer_name").classList.add("is-invalid");
        isValid = false;
    }

    // Validate phone (10-digit Indian number starting with 6-9)
    var phoneRegex = /^[6-9]\d{9}$/;
    if (!phoneRegex.test(phone)) {
        document.getElementById("phone-error").style.display = "block";
        document.getElementById("phone").classList.add("is-invalid");
        isValid = false;
    }

    // Validate address
    if (address === "") {
        document.getElementById("address-error").style.display = "block";
        document.getElementById("address").classList.add("is-invalid");
        isValid = false;
    }

    return isValid;
}
</script>

</body>
</html>
