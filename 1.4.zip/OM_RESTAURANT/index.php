<?php 

$host="localhost";
$user="root";
$dbname="om_restaurant";
$password="";

$conn= mysqli_connect("localhost", "root", "", "om_restaurant");

  if(!$conn)
  {
    echo "Connection Failed!";

  }

if($_SERVER["REQUEST_METHOD"]== "POST")
  {
      $name=$_POST['name'];
      $phone=$_POST['number'];
      $email=$_POST['email'];
      $message=$_POST['message'];

      $sql="INSERT INTO `contactus`(`name`, `number`, `email`, `message`) VALUES 
      ('$name','$phone','$email','$message')";

      $result=mysqli_query($conn,$sql);

      if($result)
      {
        echo"Message Sent Successfully!";
      }
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>OM Restaurant</title>
  <link rel="stylesheet" href="../css/style.css" />
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
    }

    header {
      background: #333;
      color: white;
      padding: 15px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .logo {
      font-size: 24px;
      font-weight: bold;
    }

    nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
    }

    nav ul li {
      margin-left: 20px;
    }

    nav ul li a {
      color: white;
      text-decoration: none;
    }

    .menu-toggle {
      display: none;
      background: none;
      border: none;
      color: white;
      font-size: 24px;
    }

    #home img {
      width: 100%;
      height: auto;
      max-height: 500px;
      object-fit: cover;
      display: block;
      margin: 0 auto;
    }

    /* ✅ Card section */
    .card-section {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      padding: 40px 20px;
      background-color: #f9f9f9;
    }

    .card {
      background: white;
      width: 300px;
      margin: 20px;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .card-content {
      padding: 20px;
    }

    .card-content h3 {
      margin-top: 0;
      color: #333;
    }

    .contact-section img {
      max-width: 100%;
      height: auto;
    }
  body, html {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: sans-serif;
  }

  section {
    width: 100%;
    padding: 40px 20px;
  }

  h2 {
    text-align: center;
    margin-bottom: 40px;
  }

  .dish-cards,
  .card-section {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 30px;
    max-width: 1200px;
    max-height: 100%;
    margin: auto;
  }

  .card {
    flex: 1 1 300px;
    margin-top: 1%;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s;
    max-width: 350px;
    height: 291px;
  }

  .card:hover {
    transform: scale(1.03);
  }

  .card img {
    width: 100%;
    height: auto;
    display: block;
  }

  .card-content {
    padding: 20px;
  }

  @media (max-width: 768px) {
    .card {
      flex: 1 1 100%;
    }
  }


  </style>
</head>

<body>

<header>
  <div class="logo">OM RESTAURANT</div>
  <nav id="navbar">
    <ul>
      <li><a href="#home">Home</a></li>
      <li><a href="#about">About</a></li>
      
      <li><a href="admin/menu.php">Menu</a></li>
      <li><a href="#contact">Contact</a></li>
      <li><a href="login.php">Login</a></li>
      
    </ul>
  </nav>
  <button class="menu-toggle" onclick="toggleMenu()">☰</button>
</header>

<main>
  <!-- ✅ Home Section -->
  <section id="home">
    <h1 style="color:blue;">Welcome to OM Restaurant</h1>
    <img src="admin/images/Restaurant.png" alt="Restaurant Image" />
  </section>

  <!-- ✅ Popular Dishes of This Month Section -->
<section class="popular-dishes">
  <h2 style="text-align:center; margin-top: 40px;">Popular Dishes of This Month</h2>
  <div class="dish-cards">
  
  </div>
</section>
        <!-- ✅ Three Card Section -->
  <section class="card-section">
    <div class="card">
      <img src="admin/images/gujrtitahali.jpg" alt="Gujarati Thali">
      <div class="card-content">
        <h3>Gujarati Thali</h3>
        <p>Enjoy the authentic taste of Gujarat with our delicious traditional thali.</p>
      </div>
    </div>
    <div class="card">
      <img src="admin/images/south-indian.jpg" alt="South Indian">
      <div class="card-content">
        <h3>South Indian Delights</h3>
        <p>Crispy dosas, spicy sambar and tangy chutneys — a South Indian experience!</p>
      </div>
    </div>
    <div class="card">
      <img src="admin/images/punjabi.jpg" alt="Chinese Food">
      <div class="card-content">
        <h3>Punjabi Special</h3>
        <p>From Punjabi Subji Nan,savor the Punjabi flavors you love.</p>
      </div>
    </div>
  </section>



  
</main>

<!-- ✅ Contact Section -->
<section id="contact" class="contact-section">
  <div class="contact-container">
    <div class="contact-image">
      <img src="admin/images/gujarati_restaurant_in_gujarat.jpg" alt="OM Restaurant">
    </div>
    <div class="contact-form">
      <h2>Contact Us</h2>
      <form action="index.php" method="post">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="tel" name="number" placeholder="Phone Number" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
        <button type="submit">Send Message</button>
      </form>
    </div>
  </div>
</section>

<!-- ✅ Footer Section -->
<footer class="site-footer">
  <link rel="stylesheet" href="../css/footer.css">
  <div class="footer-content">
    <div class="footer-about">
      <h3>OM RESTAURANT</h3>
      <p>Delicious food.</p>
    </div>
    <div class="footer-links">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="admin/menu.php">Menu</a></li>
        <li><a href="reservation.php">Reservations</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </div>
    <div class="footer-contact-info">
      <h4>Get in Touch</h4>
      <p>📞 <a href="tel:+919876543210">+91 98765 43210</a></p>
      <p>📧 <a href="mailto:info@omrestaurant.com">info@omrestaurant.com</a></p>
      <p>📍 Sarngpur, Botad, Gujarat</p>
    </div>
    <div class="footer-social">
      <h4>Follow Us</h4>
      <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/facebook--v1.png"/></a>
      <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/instagram-new.png"/></a>
      <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/twitter-squared.png"/></a>
    </div>
  </div>
  <div class="footer-bottom">
    <p>© 2025 OM RESTAURANT. All rights reserved. <a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a></p>
  </div>
</footer>

<script src="../js/script.js"></script>
</body>
</html>
