<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Add Restaurant - Food Ordering System</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #ff6b35;
            --secondary-color: #2c3e50;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --success-color: #28a745;
            --danger-color: #dc3545;
        }
        
        body {
            background-color: #f5f7fb;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #495057;
        }
        
        .sidebar {
            background-color: var(--secondary-color);
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 60px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            width: 250px;
        }
        
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 12px 20px;
            margin: 4px 0;
            border-radius: 4px;
        }
        
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 24px;
            text-align: center;
        }
        
        .navbar {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 15px 20px;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            padding-top: 80px;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 25px;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #e55a2b;
            border-color: #e55a2b;
        }
        
        .btn-inverse {
            background-color: #6c757d;
            border-color: #6c757d;
            color: white;
        }
        
        .btn-inverse:hover {
            background-color: #5a6268;
            border-color: #5a6268;
            color: white;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(255, 107, 53, 0.25);
        }
        
        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: white;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        
        .dashboard-card {
            transition: transform 0.3s;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card {
            text-align: center;
            padding: 20px;
        }
        
        .stat-card i {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: var(--primary-color);
        }
        
        .stat-card h2 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0;
        }
        
        .stat-card p {
            color: #6c757d;
            margin-bottom: 0;
        }
        
        footer {
            background-color: white;
            padding: 15px 20px;
            margin-top: 30px;
            border-top: 1px solid #e9ecef;
            text-align: center;
            color: #6c757d;
        }
        
        .alert {
            border-radius: 8px;
            padding: 12px 20px;
        }
        
        .is-invalid {
            border-color: var(--danger-color);
        }
        
        .invalid-feedback {
            display: none;
            width: 100%;
            margin-top: 0.25rem;
            font-size: 0.875em;
            color: var(--danger-color);
        }
        
        .is-invalid ~ .invalid-feedback {
            display: block;
        }
        
        .success-container {
            display: none;
            text-align: center;
            padding: 40px 20px;
        }
        
        .success-icon {
            font-size: 5rem;
            color: var(--success-color);
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
                transition: margin-left 0.3s ease;
            }
            
            .sidebar.show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 999;
            }
            
            .overlay.show {
                display: block;
            }
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>

    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="px-3 py-4">
                <h5 class="sidebar-title mb-4">Navigation</h5>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-home"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">
                            <i class="fas fa-utensils"></i> Restaurants
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-list"></i> Categories
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-shopping-cart"></i> Orders
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-users"></i> Customers
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-chart-bar"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Overlay for mobile sidebar -->
        <div class="overlay" id="overlay"></div>

        <!-- Main Content -->
        <div class="main-content w-100">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-light fixed-top">
                <div class="container-fluid">
                    <button class="btn btn-sm" type="button" id="sidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <a class="navbar-brand ms-2 fw-bold" href="#">
                        <i class="fas fa-utensils me-2"></i>Food Ordering System
                    </a>
                    
                    <div class="d-flex align-items-center">
                        <div class="dropdown me-4">
                            <a href="#" class="dropdown-toggle text-dark" id="notificationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-bell fa-lg"></i>
                                <span class="badge bg-danger rounded-pill">3</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationDropdown">
                                <li><a class="dropdown-item" href="#">New order #1234</a></li>
                                <li><a class="dropdown-item" href="#">New user registered</a></li>
                                <li><a class="dropdown-item" href="#">Restaurant added</a></li>
                            </ul>
                        </div>
                        
                        <div class="dropdown">
                            <a href="#" class="dropdown-toggle text-dark d-flex align-items-center text-decoration-none" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="https://via.placeholder.com/40" width="40" height="40" class="rounded-circle me-2">
                                <span>Admin User</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profile</a></li>
                                <li><a class="dropdown-item" href="#"><i class="fas fa-cog me-2"></i>Settings</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="#"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- Dashboard Stats -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card dashboard-card">
                        <div class="card-body stat-card">
                            <i class="fas fa-utensils"></i>
                            <h2>42</h2>
                            <p>Restaurants</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card dashboard-card">
                        <div class="card-body stat-card">
                            <i class="fas fa-shopping-cart"></i>
                            <h2>156</h2>
                            <p>Orders Today</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card dashboard-card">
                        <div class="card-body stat-card">
                            <i class="fas fa-users"></i>
                            <h2>528</h2>
                            <p>Total Users</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card dashboard-card">
                        <div class="card-body stat-card">
                            <i class="fas fa-dollar-sign"></i>
                            <h2>$3,582</h2>
                            <p>Total Revenue</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Success Message Container (Initially Hidden) -->
            <div class="card success-container" id="successMessage">
                <div class="card-body">
                    <div class="success-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <h3>Restaurant Added Successfully!</h3>
                    <p class="mb-4">The restaurant has been added to the system.</p>
                    <div class="d-flex justify-content-center gap-3">
                        <a href="#" class="btn btn-primary" id="addAnotherBtn">
                            <i class="fas fa-plus me-2"></i>Add Another Restaurant
                        </a>
                        <a href="#" class="btn btn-inverse">
                            <i class="fas fa-list me-2"></i>View All Restaurants
                        </a>
                    </div>
                </div>
            </div>

            <!-- Add Restaurant Form -->
            <div class="row" id="restaurantFormContainer">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="m-b-0 text-white">Add Restaurant</h4>
                        </div>
                        <div class="card-body">
                            <?php
                            // Database connection and form processing
                            $servername = "localhost";
                            $username = "root"; // default XAMPP username
                            $password = ""; // default XAMPP password
                            $dbname = "om_restaurant";
                            
                            // Create connection
                            $conn = new mysqli($servername, $username, $password, $dbname);
                            
                            // Check connection
                            if ($conn->connect_error) {
                                die("<div class='alert alert-danger'>Connection failed: " . $conn->connect_error . "</div>");
                            }
                            
                            // Process form submission
                            $success_message = "";
                            $error_message = "";
                            $form_submitted = false;
                            
                            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
                                $form_submitted = true;
                                
                                // Validate and sanitize inputs
                                $res_name = mysqli_real_escape_string($conn, $_POST['res_name']);
                                $email = mysqli_real_escape_string($conn, $_POST['email']);
                                $phone = mysqli_real_escape_string($conn, $_POST['phone']);
                                $url = mysqli_real_escape_string($conn, $_POST['url']);
                                $o_hr = mysqli_real_escape_string($conn, $_POST['o_hr']);
                                $c_hr = mysqli_real_escape_string($conn, $_POST['c_hr']);
                                $o_days = mysqli_real_escape_string($conn, $_POST['o_days']);
                                $c_name = mysqli_real_escape_string($conn, $_POST['c_name']);
                                $address = mysqli_real_escape_string($conn, $_POST['address']);
                                
                                // Handle file upload
                                $target_dir = "uploads/";
                                if (!file_exists($target_dir)) {
                                    mkdir($target_dir, 0777, true);
                                }
                                
                                $target_file = $target_dir . basename($_FILES["file"]["name"]);
                                $uploadOk = 1;
                                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                                
                                // Check if image file is an actual image or fake image
                                $check = getimagesize($_FILES["file"]["tmp_name"]);
                                if ($check !== false) {
                                    $uploadOk = 1;
                                } else {
                                    $error_message = "File is not an image.";
                                    $uploadOk = 0;
                                }
                                
                                // Check file size (1MB max)
                                if ($_FILES["file"]["size"] > 1000000) {
                                    $error_message = "Sorry, your file is too large. Max 1MB allowed.";
                                    $uploadOk = 0;
                                }
                                
                                // Allow certain file formats
                                if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                                && $imageFileType != "gif") {
                                    $error_message = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                                    $uploadOk = 0;
                                }
                                
                                // Check if $uploadOk is set to 0 by an error
                                if ($uploadOk == 0) {
                                    $error_message = "Sorry, your file was not uploaded. " . $error_message;
                                } else {
                                    // If everything is ok, try to upload file
                                    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
                                        // Insert into database
                                        $sql = "INSERT INTO restaurant (res_name, email, phone, url, o_hr, c_hr, o_days, image, c_name, address)
                                        VALUES ('$res_name', '$email', '$phone', '$url', '$o_hr', '$c_hr', '$o_days', '$target_file', '$c_name', '$address')";
                                        
                                        if ($conn->query($sql)) {
                                            $success_message = "Restaurant added successfully!";
                                        } else {
                                            $error_message = "Error: " . $sql . "<br>" . $conn->error;
                                        }
                                    } else {
                                        $error_message = "Sorry, there was an error uploading your file.";
                                    }
                                }
                            }
                            
                            // Display success or error messages
                            if (!empty($success_message)) {
                                echo "<div class='alert alert-success' id='successAlert'>$success_message</div>";
                            }
                            
                            if (!empty($error_message)) {
                                echo "<div class='alert alert-danger'>$error_message</div>";
                            }
                            ?>
                            
                            <form action='' method='post' enctype="multipart/form-data" id="restaurantForm">
                                <div class="form-body">
                                    <div class="row p-t-20">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label">Restaurant Name</label>
                                                <input type="text" name="res_name" class="form-control" required value="<?php if($form_submitted && !empty($error_message)) echo htmlspecialchars($res_name); ?>">
                                                <div class="invalid-feedback">Please provide a restaurant name.</div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label">Business E-mail</label>
                                                <input type="email" name="email" class="form-control" required value="<?php if($form_submitted && !empty($error_message)) echo htmlspecialchars($email); ?>">
                                                <div class="invalid-feedback">Please provide a valid email address.</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row p-t-20">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label">Phone</label>
                                                <input type="tel" name="phone" class="form-control" required value="<?php if($form_submitted && !empty($error_message)) echo htmlspecialchars($phone); ?>">
                                                <div class="invalid-feedback">Please provide a phone number.</div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label">Website URL</label>
                                                <input type="url" name="url" class="form-control" required value="<?php if($form_submitted && !empty($error_message)) echo htmlspecialchars($url); ?>">
                                                <div class="invalid-feedback">Please provide a valid URL.</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label">Open Hours</label>
                                                <select name="o_hr" class="form-control" required>
                                                    <option value="">--Select Opening Time--</option>
                                                    <option value="6am" <?php if($form_submitted && !empty($error_message) && $o_hr == '6am') echo 'selected'; ?>>6am</option>
                                                    <option value="7am" <?php if($form_submitted && !empty($error_message) && $o_hr == '7am') echo 'selected'; ?>>7am</option>
                                                    <option value="8am" <?php if($form_submitted && !empty($error_message) && $o_hr == '8am') echo 'selected'; ?>>8am</option>
                                                    <option value="9am" <?php if($form_submitted && !empty($error_message) && $o_hr == '9am') echo 'selected'; ?>>9am</option>
                                                    <option value="10am" <?php if($form_submitted && !empty($error_message) && $o_hr == '10am') echo 'selected'; ?>>10am</option>
                                                    <option value="11am" <?php if($form_submitted && !empty($error_message) && $o_hr == '11am') echo 'selected'; ?>>11am</option>
                                                    <option value="12pm" <?php if($form_submitted && !empty($error_message) && $o_hr == '12pm') echo 'selected'; ?>>12pm</option>
                                                </select>
                                                <div class="invalid-feedback">Please select opening time.</div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label">Close Hours</label>
                                                <select name="c_hr" class="form-control" required>
                                                    <option value="">--Select Closing Time--</option>
                                                    <option value="3pm" <?php if($form_submitted && !empty($error_message) && $c_hr == '3pm') echo 'selected'; ?>>3pm</option>
                                                    <option value="4pm" <?php if($form_submitted && !empty($error_message) && $c_hr == '4pm') echo 'selected'; ?>>4pm</option>
                                                    <option value="5pm" <?php if($form_submitted && !empty($error_message) && $c_hr == '5pm') echo 'selected'; ?>>5pm</option>
                                                    <option value="6pm" <?php if($form_submitted && !empty($error_message) && $c_hr == '6pm') echo 'selected'; ?>>6pm</option>
                                                    <option value="7pm" <?php if($form_submitted && !empty($error_message) && $c_hr == '7pm') echo 'selected'; ?>>7pm</option>
                                                    <option value="8pm" <?php if($form_submitted && !empty($error_message) && $c_hr == '8pm') echo 'selected'; ?>>8pm</option>
                                                    <option value="9pm" <?php if($form_submitted && !empty($error_message) && $c_hr == '9pm') echo 'selected'; ?>>9pm</option>
                                                    <option value="10pm" <?php if($form_submitted && !empty($error_message) && $c_hr == '10pm') echo 'selected'; ?>>10pm</option>
                                                    <option value="11pm" <?php if($form_submitted && !empty($error_message) && $c_hr == '11pm') echo 'selected'; ?>>11pm</option>
                                                    <option value="12am" <?php if($form_submitted && !empty($error_message) && $c_hr == '12am') echo 'selected'; ?>>12am</option>
                                                    <option value="1am" <?php if($form_submitted && !empty($error_message) && $c_hr == '1am') echo 'selected'; ?>>1am</option>
                                                    <option value="2am" <?php if($form_submitted && !empty($error_message) && $c_hr == '2am') echo 'selected'; ?>>2am</option>
                                                    <option value="3am" <?php if($form_submitted && !empty($error_message) && $c_hr == '3am') echo 'selected'; ?>>3am</option>
                                                </select>
                                                <div class="invalid-feedback">Please select closing time.</div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label">Open Days</label>
                                                <select name="o_days" class="form-control" required>
                                                    <option value="">--Select Operating Days--</option>
                                                    <option value="Mon-Tue" <?php if($form_submitted && !empty($error_message) && $o_days == 'Mon-Tue') echo 'selected'; ?>>Mon-Tue</option>
                                                    <option value="Mon-Wed" <?php if($form_submitted && !empty($error_message) && $o_days == 'Mon-Wed') echo 'selected'; ?>>Mon-Wed</option>
                                                    <option value="Mon-Thu" <?php if($form_submitted && !empty($error_message) && $o_days == 'Mon-Thu') echo 'selected'; ?>>Mon-Thu</option>
                                                    <option value="Mon-Fri" <?php if($form_submitted && !empty($error_message) && $o_days == 'Mon-Fri') echo 'selected'; ?>>Mon-Fri</option>
                                                    <option value="Mon-Sat" <?php if($form_submitted && !empty($error_message) && $o_days == 'Mon-Sat') echo 'selected'; ?>>Mon-Sat</option>
                                                    <option value="24hr-x7" <?php if($form_submitted && !empty($error_message) && $o_days == '24hr-x7') echo 'selected'; ?>>24hr-x7</option>
                                                </select>
                                                <div class="invalid-feedback">Please select operating days.</div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label">Image</label>
                                                <input type="file" name="file" class="form-control" accept="image/*" required>
                                                <small class="form-text text-muted">Max size: 1MB. Allowed formats: JPG, PNG, GIF</small>
                                                <div class="invalid-feedback">Please upload a valid image file.</div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label">Select Category</label>
                                                <select name="c_name" class="form-control" required>
                                                    <option value="">--Select Category--</option>
                                                    <option value="1" <?php if($form_submitted && !empty($error_message) && $c_name == '1') echo 'selected'; ?>>Fast Food</option>
                                                    <option value="2" <?php if($form_submitted && !empty($error_message) && $c_name == '2') echo 'selected'; ?>>Chinese</option>
                                                    <option value="3" <?php if($form_submitted && !empty($error_message) && $c_name == '3') echo 'selected'; ?>>Italian</option>
                                                    <option value="4" <?php if($form_submitted && !empty($error_message) && $c_name == '4') echo 'selected'; ?>>Mexican</option>
                                                    <option value="5" <?php if($form_submitted && !empty($error_message) && $c_name == '5') echo 'selected'; ?>>Desserts</option>
                                                </select>
                                                <div class="invalid-feedback">Please select a category.</div>
                                            </div>
                                        </div>
                                    </div>
                                    <h3 class="box-title m-t-40">Restaurant Address</h3>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <textarea name="address" class="form-control" style="height:100px;" required><?php if($form_submitted && !empty($error_message)) echo htmlspecialchars($address); ?></textarea>
                                                <div class="invalid-feedback">Please provide an address.</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-actions mt-4">
                                    <button type="submit" name="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Save Restaurant
                                    </button>
                                    <button type="reset" class="btn btn-inverse">
                                        <i class="fas fa-times me-2"></i>Cancel
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <footer class="footer">
                © 2025 - Online Food Ordering System
            </footer>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
    
    <script>
        // Preloader
        window.addEventListener('load', function() {
            document.querySelector('.preloader').style.display = 'none';
        });

        // Form validation
        document.getElementById('restaurantForm').addEventListener('submit', function(e) {
            let isValid = true;
            const inputs = this.querySelectorAll('input, select, textarea');
            
            inputs.forEach(input => {
                if (input.hasAttribute('required') && !input.value) {
                    isValid = false;
                    input.classList.add('is-invalid');
                } else {
                    input.classList.remove('is-invalid');
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                // Scroll to first invalid input
                const firstInvalid = this.querySelector('.is-invalid');
                if (firstInvalid) {
                    firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }
        });

        // Mobile sidebar toggle
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
            document.getElementById('overlay').classList.toggle('show');
        });
        
        document.getElementById('overlay').addEventListener('click', function() {
            document.getElementById('sidebar').classList.remove('show');
            this.classList.remove('show');
        });

        // Check if form was successfully submitted
        document.addEventListener('DOMContentLoaded', function() {
            const successAlert = document.getElementById('successAlert');
            if (successAlert) {
                // Hide the form and show success message
                document.getElementById('restaurantFormContainer').style.display = 'none';
                document.getElementById('successMessage').style.display = 'block';
                
                // Scroll to success message
                document.getElementById('successMessage').scrollIntoView({ behavior: 'smooth' });
            }
            
            // Add another restaurant button
            document.getElementById('addAnotherBtn').addEventListener('click', function(e) {
                e.preventDefault();
                document.getElementById('restaurantFormContainer').style.display = 'block';
                document.getElementById('successMessage').style.display = 'none';
                document.getElementById('restaurantForm').reset();
            });
        });
    </script>
</body>
</html>