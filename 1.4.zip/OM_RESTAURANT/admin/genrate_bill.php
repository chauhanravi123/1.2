<!DOCTYPE html>
<html>
<head>
    <title>Cart - Om Restaurant</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <style>
        body {
            padding-top: 70px;
            background-color: #f8f9fa;
        }
        .bill-container {
            display: none;
            background: white;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-top: 20px;
        }
        .bill-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #e9ecef;
            padding-bottom: 20px;
        }
        .bill-details {
            margin-bottom: 20px;
        }
        .bill-items {
            margin-bottom: 30px;
        }
        .bill-footer {
            border-top: 2px solid #e9ecef;
            padding-top: 20px;
            text-align: center;
            color: #6c757d;
            font-size: 0.9rem;
        }
        .bill-actions {
            margin-top: 20px;
        }
        @media print {
            body * {
                visibility: hidden;
            }
            .bill-container, .bill-container * {
                visibility: visible;
            }
            .bill-container {
                display: block !important;
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                box-shadow: none;
            }
            .bill-actions {
                display: none;
            }
            .navbar, .container > h1, .alert, .btn, table, .container > a, .container > form {
                display: none;
            }
        }
    </style>
</head>
<body class="container pt-5 my-5">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="#">Om Restaurant</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavCart">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNavCart">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="menu.php">Menu</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="cart.php">Cart</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../Myorders.php">Orders</a>
            </li>
        </ul>
        <span class="navbar-text">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
            <?php else: ?>
                <a href="login.php?redirect=cart.php" class="btn btn-outline-light btn-sm">Login</a>
            <?php endif; ?>
        </span>
    </div>
</nav>

<h1 class="mb-4">Your Cart</h1>

<?php if (!empty($success)): ?>
    <div class="alert alert-success"><?= $success ?></div>
<?php elseif (!empty($error)): ?>
    <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<?php if (empty($_SESSION['cart'])): ?>
    <p>Your cart is empty. <a href="menu.php">Go back to menu</a></p>
<?php else: ?>

    <a href="cart.php?clear=1" class="btn btn-warning mb-3" onclick="return confirm('Clear entire cart?')">Clear Cart</a>
    <a href="menu.php" class="btn btn-primary mb-3 ml-2">Add More Items</a>
    <button id="generateBill" class="btn btn-info mb-3 ml-2">Generate Bill</button>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Item</th>
                <th>Price (₹)</th>
                <th>Quantity</th>
                <th>Subtotal (₹)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $total = 0;
        foreach ($_SESSION['cart'] as $index => $item):
            $subtotal = $item['price'] * $item['quantity'];
            $total += $subtotal;
        ?>
            <tr>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td><?= number_format($item['price'], 2) ?></td>
                <td><?= $item['quantity'] ?></td>
                <td><?= number_format($subtotal, 2) ?></td>
                <td>
                    <a href="cart.php?remove=<?= $index ?>" class="btn btn-danger btn-sm" onclick="return confirm('Remove this item?')">Remove</a>
                </td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <th colspan="3" class="text-right">Total</th>
            <th>₹<?= number_format($total, 2) ?></th>
            <th></th>
        </tr>
        </tbody>
    </table>

    <!-- Bill/Invoice Container -->
    <div id="billContainer" class="bill-container">
        <div class="bill-header">
            <h2>Om Restaurant</h2>
            <p>123 Food Street, Culinary District</p>
            <p>Mumbai, Maharashtra - 400001</p>
            <p>Phone: +91 22 1234 5678 | Email: info@omrestaurant.com</p>
        </div>
        
        <div class="bill-details row">
            <div class="col-md-6">
                <p><strong>Bill No:</strong> <span id="billNumber"></span></p>
                <p><strong>Date:</strong> <span id="billDate"></span></p>
            </div>
            <div class="col-md-6 text-right">
                <p><strong>Customer Name:</strong> <?= isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'Guest' ?></p>
            </div>
        </div>
        
        <div class="bill-items">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Price (₹)</th>
                        <th>Qty</th>
                        <th>Amount (₹)</th>
                    </tr>
                </thead>
                <tbody id="billItems">
                    <!-- Items will be inserted by JavaScript -->
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="3" class="text-right">Subtotal</th>
                        <th id="billSubtotal">0.00</th>
                    </tr>
                    <tr>
                        <th colspan="3" class="text-right">GST (5%)</th>
                        <th id="billGst">0.00</th>
                    </tr>
                    <tr>
                        <th colspan="3" class="text-right">Total</th>
                        <th id="billTotal">0.00</th>
                    </tr>
                </tfoot>
            </table>
        </div>
        
        <div class="bill-footer">
            <p>Thank you for dining with us!</p>
            <p>** This is a computer generated bill and does not require a signature **</p>
        </div>
        
        <div class="bill-actions text-center">
            <button onclick="window.print()" class="btn btn-primary">Print Bill</button>
            <button id="closeBill" class="btn btn-secondary">Close</button>
        </div>
    </div>

    <!-- Checkout Form -->
    <h3 class="mt-4">Checkout</h3>
    <?php if (!isset($_SESSION['user_id'])): ?>
        <div class="alert alert-warning">
            Please <a href="../login.php?redirect=cart.php">log in</a> to proceed with checkout.
        </div>
    <?php else: ?>
        <form method="POST">
            <div class="form-group">
                <label>Customer Name</label>
                <input type="text" name="customer_name" class="form-control" required>
            </div>
            <button type="submit" name="checkout" class="btn btn-success">Place Order</button>
        </form>
    <?php endif; ?>

<?php endif; ?>

<a href="menu.php" class="btn btn-secondary mt-4">Back to Menu</a>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const generateBillBtn = document.getElementById('generateBill');
        const closeBillBtn = document.getElementById('closeBill');
        const billContainer = document.getElementById('billContainer');
        
        generateBillBtn.addEventListener('click', function() {
            // Generate bill number and date
            const now = new Date();
            const billNumber = 'OM' + now.getFullYear() + (now.getMonth() + 1) + now.getDate() + 
                              now.getHours() + now.getMinutes() + now.getSeconds();
            
            document.getElementById('billNumber').textContent = billNumber;
            document.getElementById('billDate').textContent = now.toLocaleString();
            
            // Calculate bill details
            const cartItems = <?php echo json_encode($_SESSION['cart']); ?>;
            const billItemsContainer = document.getElementById('billItems');
            billItemsContainer.innerHTML = '';
            
            let subtotal = 0;
            
            cartItems.forEach(item => {
                const itemTotal = item.price * item.quantity;
                subtotal += itemTotal;
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.name}</td>
                    <td>${parseFloat(item.price).toFixed(2)}</td>
                    <td>${item.quantity}</td>
                    <td>${itemTotal.toFixed(2)}</td>
                `;
                billItemsContainer.appendChild(row);
            });
            
            const gst = subtotal * 0.05;
            const total = subtotal + gst;
            
            document.getElementById('billSubtotal').textContent = subtotal.toFixed(2);
            document.getElementById('billGst').textContent = gst.toFixed(2);
            document.getElementById('billTotal').textContent = total.toFixed(2);
            
            // Show the bill
            billContainer.style.display = 'block';
            
            // Scroll to bill
            billContainer.scrollIntoView({ behavior: 'smooth' });
        });
        
        closeBillBtn.addEventListener('click', function() {
            billContainer.style.display = 'none';
        });
    });
</script>

</body>
</html>