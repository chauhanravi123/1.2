<?php
// DB connection
$servername = "localhost";
$username = "root";
$password = "";  
$dbname = "om_restaurant";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {

  
    // Not logged in, redirect to login page
    header('Location: index.php');
    exit;
}

// Initialize variables with empty values
$id = $item_name = $category = $price = $img = $descrption = "";
$updateSuccess = false;

// FIRST: Fetch existing data when page loads (not just on POST)
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM menu_items WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $item_name = $row['item_name'];
        $descrption = $row['descrption']; // Note: Check if this is a typo (should be description?)
        $category = $row['category'];
        $price = $row['price'];
        $img = $row['img'];
    }
}

// THEN: Check if form is submitted for update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $item_name = $_POST['item_name'];
    $descrption = $_POST['descrption'];
    $category = $_POST['category'];
    $price = $_POST['price'];

    // File upload handling
    if (isset($_FILES['img']) && $_FILES['img']['error'] === UPLOAD_ERR_OK) {
        $img_tmp = $_FILES['img']['tmp_name'];
        $img_name = basename($_FILES['img']['name']);
        $upload_dir = 'uploads/';
        $img_path = $upload_dir . $img_name;

        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        move_uploaded_file($img_tmp, $img_path);
    } else {
        // Keep existing image if no new file uploaded
        $img_path = $img; // Using the $img value we fetched earlier
    }

    // Update statement
    $stmt = $conn->prepare("UPDATE menu_items SET item_name=?, descrption=?, category=?, price=?, img=? WHERE id=?");
    $stmt->bind_param("sssdsi", $item_name, $descrption, $category, $price, $img_path, $id);

    if ($stmt->execute()) {
        $updateSuccess = true;
        // Refresh the data after update
        $stmt = $conn->prepare("SELECT * FROM menu_items WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        // Update variables with fresh data
        $item_name = $row['item_name'];
        $descrption = $row['descrption'];
        $category = $row['category'];
        $price = $row['price'];
        $img = $row['img'];
    }
}
?>

<!-- HTML Form remains the same -->







<!-- HTML Form -->
<!DOCTYPE html>
<html>
<head>
    <title>Update Menu Item</title>
    <style>

        /* Container */
.update-form {
  max-width: 400px;
  margin: 30px auto;
  padding: 20px 25px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background: #fafafa;
  font-family: Arial, sans-serif;
}

/* Form labels */
.update-form label {
  display: block;
  margin-bottom: 6px;
  font-weight: 600;
  color: #333;
}

/* Inputs */
.update-form input[type="text"],
.update-form input[type="number"],
.update-form input[type="file"] {
  width: 100%;
  padding: 8px 12px;
  margin-bottom: 15px;
  border: 1.5px solid #ccc;
  border-radius: 4px;
  font-size: 1rem;
  box-sizing: border-box;
  transition: border-color 0.3s ease;
}

/* Input focus */
.update-form input[type="text"]:focus,
.update-form input[type="number"]:focus,
.update-form input[type="file"]:focus {
  border-color: #007bff;
  outline: none;
}

/* Submit button */
.update-form button {
  width: 100%;
  background-color: #007bff;
  color: white;
  border: none;
  padding: 12px 0;
  font-size: 1.1rem;
  font-weight: bold;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.update-form button:hover {
  background-color: #0056b3;
}

    </style>
</head>
<body>
    <h2>Update Menu Item</h2>

    <?php if ($updateSuccess): ?>
        <p style="color: green;">Item updated successfully!</p>
    <?php endif; ?>

    <form action="update_menu.php" method="post" enctype="multipart/form-data" class="update-form">
        <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">

        <label>Item Name:</label><br>
        <input type="text" id="name" name="item_name" value="<?= htmlspecialchars($item_name) ?>" required><br><br>

        <label>Descrption</label>
        <input type="text" id="name" name="descrption" value="<?=htmlspecialchars($descrption)?>"required><br><br>

        <label>Category:</label><br>
        <input type="text" id="name" name="category" value="<?= htmlspecialchars($category) ?>" required><br><br>

        <label>Price:</label><br>
        <input type="number" id="price" step="0.01" name="price" value="<?= htmlspecialchars($price) ?>" required><br><br>

        <label>Image URL:</label><br>
       <input type="file" name="img" id="img" accept="image/*" value="<?= htmlspecialchars($img ?? '') ?>"><br><br>

        <button type="submit">Update</button>
    </form>
</body>
</html>

  
